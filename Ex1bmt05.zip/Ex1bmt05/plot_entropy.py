
import numpy as np
import matplotlib.pyplot as plt

# set paths
root_result = 'result_1D/'   # where to save trained models


# filename
example = 1
C_rev = [ 1, 20, 50, 100, 500,  2000, 5000]




 # plots
plt.figure()
plt.style.use('seaborn-colorblind')


ax = plt.subplot(1, 1, 1)
min_entr = np.zeros(7)
idx = 0
for ii in C_rev:
    
    filename = root_result + str(ii) + '/train_lambda' +  str(ii) + '.npy'
    with open(filename, 'rb') as f:
        valida_loss = np.load(f)
    
    # row_valid = 

    epoch = valida_loss[:,0]
    total_loss = valida_loss[:,1]
    cross_entr = valida_loss[:,2]

    min_entr[idx] = cross_entr[-1]
    idx = idx + 1
ax.semilogx(C_rev, min_entr, marker = 'o')

plt.text(1.1, min_entr[0], '$\lambda = 1$',fontsize = 15)
plt.text(35, min_entr[3], '$\lambda = 50$',fontsize = 15)

plt.xlabel('$\lambda$',fontsize = 23)
# plt.ylim(0,0.2)
plt.ylabel('cross-entropy $H$', fontsize = 23)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.show()
plt.savefig('cross_entr1.png',bbox_inches="tight")





#  # plots
# plt.figure(figsize=(10, 5))
# ax = plt.subplot(1, 2, 1)
# ax2 = plt.subplot(1, 2, 2)
# min_entr = np.zeros(12)
# idx = 0
# for ii in C_rev:
    
#     filename = root_result + str(example) + '/' + str(ii) + '/train_lambda' +  str(ii) + '.npy'
#     with open(filename, 'rb') as f:
#         valida_loss = np.load(f)
    
#     # row_valid = 

#     epoch = valida_loss[:,0]
#     total_loss = valida_loss[:,1]
#     cross_entr = valida_loss[:,2]

   
#     ax.plot(epoch, cross_entr)
#     min_entr[idx] = np.ndarray.min(cross_entr)

#     idx = idx + 1

# ax2.semilogx(C_rev, min_entr)
# plt.grid(True, which="both")
# plt.show()
# plt.savefig('cross_entr.png', dpi=150, bbox_inches='tight')


exit()
