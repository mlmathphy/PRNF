import numpy as np
from numpy.random import random
from scipy import interpolate
import matplotlib.pyplot as plt
import os

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)



def f_x(x):
    
    ## type 1:
    # fx = 1.0 * np.logical_and(x>=1, x<=2)

    ## type 2:
    # fx = np.sin( 3*np.pi/5 *x )**2

    ## type 3:
    sigma = 0.5
    fx = 2/(np.sqrt(3*sigma) * np.pi**(1/4)) * ( 1 - ((x-2.5)/sigma)**2 ) * np.exp( - (x-2.5)**2 / (2*sigma**2) ) + 0.6

    return fx

def sample(g):
    x = np.linspace(0,5,100000)
    y = g(x)                        # probability density function, pdf
    cdf_y = np.cumsum(y)            # cumulative distribution function, cdf
    cdf_y = cdf_y/cdf_y.max()       # takes care of normalizing cdf to 1.0
    inverse_cdf = interpolate.interp1d(cdf_y,x)    # this is a function

    return inverse_cdf

def return_samples(N):
    # let's generate some samples according to the chosen pdf, f(x,y,z)
    uniform_samples_x = random(int(N))

    required_samples = sample(f_x)(uniform_samples_x)    
    return required_samples


## plot
x = np.linspace(0,5,10000) # for plot
plt.rcParams.update({'font.size': 23})
plt.figure()
plt.style.use('seaborn-colorblind')


ax = plt.axvline(x = 4)

# num_samples = 50000
# return_x = return_samples(num_samples)
# ax = plt.plot(x,f_x(x)/np.sum(f_x(x)*(x[1]-x[0])) )


# x direction
plt.xlabel('x', fontsize = 23)
plt.ylabel('density', fontsize = 23)
plt.xlim(0, 5)
plt.ylim(0, 1.1)
# axes.hist(return_x,bins='auto',density=True,range=(x.min(),x.max()))

plt.show() 
plt.savefig('inverse_delta.png', bbox_inches="tight", dpi=300)


exit()
savedir = 'data/initial/'
make_folder(savedir)
filename = 'hat'
## Saving validation results vs epoch to .npy file  
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, return_x)