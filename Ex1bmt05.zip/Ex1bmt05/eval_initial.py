import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
import torch.nn as nn
import scipy.integrate as integrate


device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/initial/'       # where the datasets are

data = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization
    with open('data/data_mean_std.npy', 'rb') as f:
        mu = np.load(f)
        s = np.load(f)


    assert isinstance(name, str), 'Name must be a string'
    global data, data_name

    if data_name == name:
        return

    elif name == 'test_delta':
        y0 = 4.0 * np.ones(50000)

    elif name == 'test_hat':
        y0 = np.load('data/initial/hat.npy')

    elif name == 'test_sin2':
        y0 = np.load('data/initial/sin2.npy')

    elif name == 'test_ricker':
        y0 = np.load('data/initial/ricker.npy')

    else:
        raise ValueError('Unknown dataset')
    
    n, = y0.shape
    yt = (np.sqrt(y0) + 1 + np.random.randn(n)) ** 2
    data = np.stack((y0, yt), axis=-1)
    data = (data - mu)/s
    data_name = name



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = 'BM1D_lambda50'

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def backward(self, x, dim):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x


def p_trans_delta(x):
    time = 0.1
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) *  ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(4) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(4) + time) ** 2) )

    return p_trans



def p_trans_hat(x0, x):
    time = 0.1
    fx = 1.0 * np.logical_and(x0>=1, x0<=2)
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans

def p_trans_sin2(x0, x):
    time = 0.1
    fx = np.sin( 3*np.pi/5 *x0 )**2
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans

def p_trans_ricker(x0, x):
    time = 0.1
    sigma = 0.5
    fx = 2/(np.sqrt(3*sigma) * np.pi**(1/4)) * ( 1 - ((x0-2.5)/sigma)**2 ) * np.exp( - (x0-2.5)**2 / (2*sigma**2) ) + 0.6

    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans


def probabilityXt(x, example):

    result = np.zeros_like(x)

    if example == 1:
        for i in range(x.shape[0]):
            result = p_trans_delta(x)

    if example == 2:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_hat, 0, 5, args = (x[i],) )[0]

    elif example == 3:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_sin2, 0, 5, args = (x[i],) )[0]


    elif example == 4:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_ricker, 0, 5, args = (x[i],) )[0]


    return result

def test_initialGreen(name):

    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    dim = 1
    print('dimensionality is ', dim)
    try:
        NF = load_model(dim)

    except IOError:
        return 'N/A'



    ## test:
    N_test,_ = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(N_test,dim)
    y0 = data[:,:dim]
    y_test = data[:,dim:]    # true
    y0z_sample0 = np.column_stack( (y0,z_sample0) )
    y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
    y0_y = NF.backward(y0z_sample, dim)
    y = y0_y[:,dim:2 * dim]

    y_pred = y.to('cpu').detach().numpy()   # approximation

    with open('data/data_mean_std.npy', 'rb') as f:
        mu = np.load(f)
        std = np.load(f)

    y_pred = std[1] * y_pred + mu[1]


    ## plots
    # plt.rcParams.update({'font.size': 23})

    plt.figure()
    plt.style.use('seaborn-colorblind')
    # for kl_div
    xl,xr = 0.1, 10
    x_kl = np.linspace(xl,xr, 1000)
    ## compute elementwise KL divergece

    if data_name == 'test_delta':
        example = 1

    elif data_name == 'test_hat':
        example = 2

    elif data_name == 'test_sin2':
        example = 3

    elif data_name == 'test_ricker':
        example = 4

    kl_test = probabilityXt(x_kl, example)
    kl_test = kl_test/np.sum(kl_test*(x_kl[1]-x_kl[0]))

    plt.cla()
    ax = plt.plot(x_kl,kl_test, color="r")
    ax = plt.hist(y_pred, density=True, bins=50)
    plt.xlabel('x',fontsize=23)
    plt.xlim(0, xr)
    # plt.ylim(0,0.2)
    plt.ylabel('density',fontsize=23)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)

    plt.grid()        
    plt.legend([' exact pdf', 'PR-NF samples'],fontsize = 14, loc = 'upper right')
    plt.savefig('img_' + data_name + '.png', bbox_inches="tight", dpi=300 )

    





def main():


    for initial in sys.argv[1:]:

        if initial == 'test_delta':
            test_initialGreen(initial)

        elif initial == 'test_hat':
            test_initialGreen(initial)

        elif initial == 'test_sin2':
            test_initialGreen(initial)

        elif initial == 'test_ricker':
            test_initialGreen(initial)

        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
