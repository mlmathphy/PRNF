import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim
import scipy.integrate as integrate
import matplotlib.pyplot as plt
import math
import scipy.special as special
from scipy.stats import norm
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)
root_data = 'data/initial/'      # where the datasets are
root_output = 'output/'   # where to save trained models

seed = 12345
torch.manual_seed(seed)
np.random.seed(seed)
criterion = nn.MSELoss()

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """
    if not os.path.exists(folder):
        os.makedirs(folder)


def p_trans(x0,x):
    # fx = 0.2 * np.logical_and(x0>=0, x0<=5)
    time = 0.1
    
    
    # sigma = 0.5
    # fx = 2/(np.sqrt(3*sigma) * np.pi**(1/4)) * ( 1 - ((x0-2.5)/sigma)**2 ) * np.exp( - (x0-2.5)**2 / (2*sigma**2) ) + 0.6
    

    
    # fx = 1.0 * np.logical_and(x0>=1, x0<=2)



    fx = np.sin( 3*np.pi/5 *x0 )**2


    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )


    # p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(3) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(3) + time) ** 2) )

    return p_trans


def probabilityXt(x):
    print(x.shape)
    result = np.zeros_like(x)
    for i in range(x.shape[0]):
        result[i] = integrate.quad(p_trans, 0, 5, args = (x[i],) )[0]

    return result






# ------------------------------------------------
#                The main routine
# ------------------------------------------------
plt.figure()
plt.style.use('seaborn-colorblind')


X0 = np.load(root_data + 'ricker.npy')
X0 = np.repeat(X0, 1)
Ns = X0.shape[0]
print(X0.shape)

time = 0.1
# X0 = 5 * np.random.rand(Ns)
Wt = np.random.normal(0, np.sqrt(time), Ns)
Xt = (np.sqrt(X0) + time + Wt)**2




# analy:
xl,xr = 0.01,10
x = np.linspace(xl,xr, 1000)
y_test = probabilityXt(x)


plt.cla()
# ax = plt.hist(X0, density = True, bins = 200)
ax = plt.plot(x,y_test/np.sum(y_test*(x[1]-x[0])), color="r")
ax = plt.hist(Xt, density=True, bins=50)

plt.xlabel('x')
plt.xlim(0, xr)
# plt.ylim(0,0.2)
plt.ylabel('density')
plt.grid()        
plt.legend([' exact pdf', 'PRNF samples'],fontsize = 15,loc = 'upper right')


plt.savefig('img_temp.pdf', dpi='figure')
exit()






















