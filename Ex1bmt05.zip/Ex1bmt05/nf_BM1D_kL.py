import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim
import scipy.integrate as integrate
from scipy import interpolate
import matplotlib.pyplot as plt
import math
from scipy import stats
import scipy.special as special
from scipy.stats import norm
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)

root_output = 'output/'   # where to save trained models
root_data = 'data/initial/'      # where the datasets are
savedir = 'train_result/'

data = None
data_name = None

seed = 12345
torch.manual_seed(seed)
np.random.seed(seed)
criterion = nn.MSELoss()

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """
    if not os.path.exists(folder):
        os.makedirs(folder)


def jacobian(output, input):

    n, dim= input.shape
    d = int(dim/2)
    w = torch.ones_like(input[:,[0]])

    jacob1 = torch.empty(d, n, 2 * d)
    input1 = input
    output1 = output[:, d:2 * d]
    for i in range(d):
        output1_i = output1[:, [i]]
        jacob1[i] = torch.autograd.grad(output1_i, input1, w, create_graph=True)[0]

    jacob1 = jacob1.permute(1, 0, 2)
    jacob1 = jacob1[:,:,d:2 * d]
    return jacob1





def save_model(model, C_rev):
    """
    Save pytorch NN model.
    """

    savedir = root_output
    make_folder(savedir)

    filename = 'BM1D_lambda' + str(C_rev)
    checkpoint = {'state_dict': model.state_dict()}
    torch.save(checkpoint, savedir + filename + '.pt')





class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def forward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.input(x))
        x = torch.tanh(self.fc1(x))
        x = self.output(x)
        x = torch.cat((y0, x), 1)
        return x


    def backward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x


    def get_grad(self, x):
     
        x.requires_grad_(True)
        xx = self.forward(x)
        jac = jacobian(xx,x)
        return jac


def standard_normal_logprob(z):
    logZ = -0.5 * math.log(2 * math.pi)
    return logZ - z.pow(2) / 2

def loss_fun(model, y, dim, C_rev):

    NF = model.to(device)
    z = NF.forward(y)

    ## loss1: forward loss:
    loss1 = - 1.0 * torch.mean( torch.sum(standard_normal_logprob(z[:,dim:2*dim]), axis = 1, keepdim=False), axis = 0)

    ## loss2: det of jacobian
    jac = torch.abs(torch.linalg.det(NF.get_grad(y)))
    loss2 = -1.0 * torch.mean(torch.log(jac))

    ## loss3: backward loss
    y_pred = NF.backward(z)
    loss3 = torch.mean( (y_pred[:,dim:2*dim] - y[:,dim:2*dim])**2 )

    # print(loss1, loss2, loss3)
    loss = loss1 * 1.0 + loss2 * 1.0 + loss3 * C_rev

    return loss


def uni_fun(Ns):
    time = 0.1
    a = 5 * np.random.rand(Ns)
    b = (np.sqrt(a) + time + np.random.normal(0, np.sqrt(time), Ns)) ** 2
    y = np.stack((a, b), axis=-1)
    mu = y.mean(axis=0)
    s = y.std(axis=0)

    return y, mu, s



def target_fun(Ns, example):
    time = 0.1
    if example == 1:
        a = 4 * np.ones(Ns)
        b = (np.sqrt(a) + time + np.random.normal(0, np.sqrt(time), Ns)) ** 2
        y = np.stack((a, b), axis=-1)


    elif example == 2:
        a = np.load(root_data + 'hat.npy')
        Ns = a.shape[0]
        print(Ns)
        b = (np.sqrt(a) + time + np.random.normal(0, np.sqrt(time), Ns)) ** 2
        y = np.stack((a, b), axis=-1)


    elif example == 3:
        a = np.load(root_data + 'sin2.npy')
        Ns = a.shape[0]
        b = (np.sqrt(a) + time + np.random.normal(0, np.sqrt(time), Ns)) ** 2
        y = np.stack((a, b), axis=-1)


    elif example == 4:
        a = np.load(root_data + 'ricker.npy')
        Ns = a.shape[0]
        b = (np.sqrt(a) + time + np.random.normal(0, np.sqrt(time), Ns)) ** 2
        y = np.stack((a, b), axis=-1)

    return y



def p_trans_delta(x):
    time = 0.1
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) *  ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(4) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(4) + time) ** 2) )

    return p_trans



def p_trans_hat(x0, x):
    time = 0.1
    fx = 1.0 * np.logical_and(x0>=1, x0<=2)
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans

def p_trans_sin2(x0, x):
    time = 0.1
    fx = np.sin( 3*np.pi/5 *x0 )**2
    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans

def p_trans_ricker(x0, x):
    time = 0.1
    sigma = 0.5
    fx = 2/(np.sqrt(3*sigma) * np.pi**(1/4)) * ( 1 - ((x0-2.5)/sigma)**2 ) * np.exp( - (x0-2.5)**2 / (2*sigma**2) ) + 0.6

    p_trans = 1/np.sqrt(2 * np.pi) / 2 / np.sqrt(time*x) * fx * ( np.exp(-1 / (2*time) * (np.sqrt(x) - np.sqrt(x0) - time) ** 2) + np.exp(-1 / (2*time) * (np.sqrt(x) + np.sqrt(x0) + time) ** 2) )

    return p_trans


def probabilityXt(x, example):

    result = np.zeros_like(x)

    if example == 1:
        for i in range(x.shape[0]):
            result = p_trans_delta(x)

    if example == 2:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_hat, 0, 5, args = (x[i],) )[0]

    elif example == 3:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_sin2, 0, 5, args = (x[i],) )[0]


    elif example == 4:
        for i in range(x.shape[0]):
            result[i] = integrate.quad(p_trans_ricker, 0, 5, args = (x[i],) )[0]


    return result


# ------------------------------------------------
#                The main routine
# ------------------------------------------------
plt.figure()
plt.style.use('seaborn-colorblind')


C_rev = 50
# The index of the function
dim = 1
# The number of testing set
NTest = 50000
# The number of training set
NTrain = 20000

y_train0, mu, std = uni_fun(NTrain)
y_train0 = (y_train0 - mu)/std
y_train = torch.as_tensor(y_train0,dtype=torch.float,device = device)



## testing dataset
## delta function
y_v0_delta4 = target_fun(NTest, 1)
y_v0_delta4 = (y_v0_delta4 - mu)/std
## hat function
y_v0_hat = target_fun(NTest, 2)
y_v0_hat = (y_v0_hat - mu)/std
## sin2 function
y_v0_sin2 = target_fun(NTest, 3)
y_v0_sin2 = (y_v0_sin2 - mu)/std
## delta function
y_v0_ricker = target_fun(NTest, 4)
y_v0_ricker = (y_v0_ricker - mu)/std


NF = NF_Net(dim).to(device)
NF.zero_grad()

# Learning rate
learning_rate = 0.01
optimizer = optim.Adam(NF.parameters(), lr=learning_rate)

loss_record = np.empty((0,6), float)

n_iter = 440

savedir = 'result_1D/klplot/'
make_folder(savedir)

# for kl_div
xl,xr = 0.01,10
x_kl = np.linspace(xl,xr, 2000)
## delta4
y0_delta4 = y_v0_delta4[:,:dim]
z = np.random.randn(NTest,1)
y0_z_delta4 = np.column_stack((y0_delta4,z))
y0_z_delta4 = torch.as_tensor(y0_z_delta4,dtype=torch.float,device = device)
##
y0_hat = y_v0_hat[:,:dim]
z = np.random.randn(NTest,1)
y0_z_hat = np.column_stack((y0_hat,z))
y0_z_hat = torch.as_tensor(y0_z_hat,dtype=torch.float,device = device)

y0_sin2 = y_v0_sin2[:,:dim]
z = np.random.randn(NTest,1)
y0_z_sin2 = np.column_stack((y0_sin2,z))
y0_z_sin2 = torch.as_tensor(y0_z_sin2,dtype=torch.float,device = device)

y0_ricker = y_v0_ricker[:,:dim]
z = np.random.randn(NTest,1)
y0_z_ricker = np.column_stack((y0_ricker,z))
y0_z_ricker = torch.as_tensor(y0_z_ricker,dtype=torch.float,device = device)

for i in range(n_iter):
    optimizer.zero_grad()

    if i > 1000:
        optimizer.param_groups[0]["lr"] = 0.001

    elif i > 5000:
        optimizer.param_groups[0]["lr"] = 0.0001

    if i % 4 == 0:
        print('iteration step: ' + '{0:1d}'.format(i))

        loss = loss_fun(NF, y_train, dim, C_rev)
        print(loss)

        ## validation test
        ## delta4
        # y0_y = NF.backward(y0_z_delta4)
        # y = y0_y[:,dim:2 * dim]
        # y_pred = y.to('cpu').detach().numpy().flatten()
        # y_test = y_v0_delta4[:,dim:2*dim]

        # y_pred = (std[1] * y_pred + mu[1]).flatten()
        # y_test = (std[1] * y_test + mu[1]).flatten()

        # kernel_test = stats.gaussian_kde(y_test, bw_method=0.1)
        # kernel_pred = stats.gaussian_kde(y_pred, bw_method=0.1)

        # y_test_kl = y_test[np.random.choice(NTest, 20000, replace=False)]

        # kl_delta4 = np.mean( np.log(  kernel_test(  y_test_kl   )   /  ( kernel_pred(y_test_kl) + 1e-20)  ) )


        # ## hat
        # y0_y = NF.backward(y0_z_hat)
        # y = y0_y[:,dim:2 * dim]
        # y_pred = y.to('cpu').detach().numpy().flatten()
        # y_test = y_v0_hat[:,dim:2*dim]

        # y_pred = (std[1] * y_pred + mu[1]).flatten()
        # y_test = (std[1] * y_test + mu[1]).flatten()

        # kernel_test = stats.gaussian_kde(y_test, bw_method=0.1)
        # kernel_pred = stats.gaussian_kde(y_pred, bw_method=0.1)
        
        # y_test_kl = y_test[np.random.choice(NTest, 20000, replace=False)]
        # kl_hat = np.mean( np.log(  kernel_test(  y_test_kl   )   /  ( kernel_pred(y_test_kl) + 1e-20)  ) )


        # ## sin2
        # y0_y = NF.backward(y0_z_sin2)
        # y = y0_y[:,dim:2 * dim]
        # y_pred = y.to('cpu').detach().numpy().flatten()
        # y_test = y_v0_sin2[:,dim:2*dim]

        # y_pred = (std[1] * y_pred + mu[1]).flatten()
        # y_test = (std[1] * y_test + mu[1]).flatten()

        # kernel_test = stats.gaussian_kde(y_test, bw_method=0.1)
        # kernel_pred = stats.gaussian_kde(y_pred, bw_method=0.1)
        
        # y_test_kl = y_test[np.random.choice(NTest, 20000, replace=False)]
        # kl_sin2 = np.mean( np.log(  kernel_test(  y_test_kl   )   /  ( kernel_pred(y_test_kl) + 1e-20)  ) )

        # ## ricker
        # y0_y = NF.backward(y0_z_ricker)
        # y = y0_y[:,dim:2 * dim]
        # y_pred = y.to('cpu').detach().numpy().flatten()
        # y_test = y_v0_ricker[:,dim:2*dim]

        # y_pred = (std[1] * y_pred + mu[1]).flatten()
        # y_test = (std[1] * y_test + mu[1]).flatten()

        # kernel_test = stats.gaussian_kde(y_test, bw_method=0.1)
        # kernel_pred = stats.gaussian_kde(y_pred, bw_method=0.1)
        
        # y_test_kl = y_test[np.random.choice(NTest, 20000, replace=False)]
        # kl_ricker = np.mean( np.log(  kernel_test(  y_test_kl   )   /  ( kernel_pred(y_test_kl) + 1e-20)  ) )


        # print(kl_delta4, kl_hat, kl_sin2, kl_ricker)

        # loss_record = np.append(loss_record, [[i, loss.cpu().detach().numpy(), kl_delta4, kl_hat, kl_sin2, kl_ricker]], axis=0)



        y0_y = NF.backward(y0_z_delta4)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy().flatten()
        kl_test = probabilityXt(x_kl, 1)
        kl_test = kl_test/np.sum(kl_test*(x_kl[1]-x_kl[0]))
        y_pred = std[1] * y_pred + mu[1]
        kernel = stats.gaussian_kde(y_pred, bw_method=0.1)
        kl_delta4 = np.sum( kl_test*(x_kl[1]-x_kl[0]) * np.log(  (kl_test + 1e-20) /  ( kernel(x_kl) + 1e-20)  ) )




        y0_y = NF.backward(y0_z_hat)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy().flatten()
        kl_test = probabilityXt(x_kl, 2)
        kl_test = kl_test/np.sum(kl_test*(x_kl[1]-x_kl[0]))
        y_pred = std[1] * y_pred + mu[1]
        kernel = stats.gaussian_kde(y_pred, bw_method=0.1)
        kl_hat = np.sum( kl_test*(x_kl[1]-x_kl[0]) * np.log(  (kl_test + 1e-20) /  ( kernel(x_kl) + 1e-20)  ) )



        y0_y = NF.backward(y0_z_sin2)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy().flatten()
        kl_test = probabilityXt(x_kl, 3)
        kl_test = kl_test/np.sum(kl_test*(x_kl[1]-x_kl[0]))
        y_pred = std[1] * y_pred + mu[1]
        kernel = stats.gaussian_kde(y_pred, bw_method=0.1)
        kl_sin2 = np.sum( kl_test*(x_kl[1]-x_kl[0]) * np.log(  (kl_test + 1e-20) /  ( kernel(x_kl) + 1e-20)  ) )


        y0_y = NF.backward(y0_z_ricker)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy().flatten()
        kl_test = probabilityXt(x_kl, 4)
        kl_test = kl_test/np.sum(kl_test*(x_kl[1]-x_kl[0]))
        y_pred = std[1] * y_pred + mu[1]
        kernel = stats.gaussian_kde(y_pred, bw_method=0.1)
        kl_ricker = np.sum( kl_test*(x_kl[1]-x_kl[0]) * np.log(  (kl_test + 1e-20) /  ( kernel(x_kl) + 1e-20)  ) )

        print(kl_delta4, kl_hat, kl_sin2, kl_ricker)

        loss_record = np.append(loss_record, [[i, loss.cpu().detach().numpy(), kl_delta4, kl_hat, kl_sin2, kl_ricker]], axis=0)



    else:
        loss = loss_fun(NF, y_train, dim, C_rev)
    
    loss.backward()
    optimizer.step()


## Saving validation results vs epoch to .npy file  
with open(savedir + 'train_loss_kl.npy', 'wb') as f:
    np.save(f, loss_record)


exit()






















