
import numpy as np
import matplotlib.pyplot as plt

# set paths
root_result = 'result_1D/klplot/'   # where to save trained models

filename = root_result + 'train_loss_kl.npy'


 # plots
plt.figure(figsize=(10,5))
ax = plt.subplot(1, 2, 1)
ax2 = plt.subplot(1, 2, 2)

with open(filename, 'rb') as f:
    loss_kl = np.load(f)

# row_valid = 

epoch = loss_kl[0:22,0]

total_loss = loss_kl[:22,1]

kl_delta4 = loss_kl[:22,2]
kl_hat = loss_kl[:22,3]
kl_sin2 = loss_kl[:22,4]
kl_ricker = loss_kl[:22,5]

ax.semilogy(epoch, total_loss, label='training dataset')


ax2.semilogy(epoch, kl_delta4, label="$\delta$ func")
ax2.semilogy(epoch, kl_hat, label="bar")
ax2.semilogy(epoch, kl_sin2, label="sin2")
ax2.semilogy(epoch, kl_ricker, label="ricker")

# print(kl_delta3)

# ax.set_xlabel('epoch',fontsize = 10)
ax.set_ylabel('loss $\mathcal{L}$', fontsize = 14)
ax.legend(loc="upper right")
ax2.set_xlabel('epoch',fontsize = 14)
ax2.set_ylabel('KL-divergence', fontsize = 14)
ax2.legend(loc="upper right")

plt.tight_layout()
plt.legend()
plt.show()
plt.savefig('kl_loss.png', dpi=300)





#  # plots
# plt.figure(figsize=(10, 5))
# ax = plt.subplot(1, 2, 1)
# ax2 = plt.subplot(1, 2, 2)
# min_entr = np.zeros(12)
# idx = 0
# for ii in C_rev:
    
#     filename = root_result + str(example) + '/' + str(ii) + '/train_lambda' +  str(ii) + '.npy'
#     with open(filename, 'rb') as f:
#         valida_loss = np.load(f)
    
#     # row_valid = 

#     epoch = valida_loss[:,0]
#     total_loss = valida_loss[:,1]
#     cross_entr = valida_loss[:,2]

   
#     ax.semilogy(epoch, cross_entr)
#     min_entr[idx] = np.ndarray.min(cross_entr)

#     idx = idx + 1

# ax2.semilogy(C_rev, min_entr)
# plt.grid(True, which="both")
# plt.show()
# plt.savefig('cross_entr.png', dpi=100, bbox_inches='tight')


exit()
