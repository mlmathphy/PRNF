import numpy as np
from numpy.random import random
from scipy import interpolate
import matplotlib.pyplot as plt
import os

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)



def f_x(x):
    # does not need to be normalized
    x_0 = 3.0 * np.pi/2.0
    sigma_x = np.pi/3.0
    return np.exp( -(x-x_0)**2 /  sigma_x**2)

def f_y(y):
    # does not need to be normalized
    y_0 = np.pi
    sigma_y = np.pi/5.0
    return np.exp( -(y-y_0)**2 /  sigma_y**2)

def f_z(z):
    # does not need to be normalized
    z_0 = np.pi
    sigma_z = np.pi/4.0
    return np.exp( -(z-z_0)**2 /  sigma_z**2)

def sample(g):
    x = np.linspace(0,2*np.pi,10000000)
    y = g(x)                        # probability density function, pdf
    cdf_y = np.cumsum(y)            # cumulative distribution function, cdf
    cdf_y = cdf_y/cdf_y.max()       # takes care of normalizing cdf to 1.0
    inverse_cdf = interpolate.interp1d(cdf_y,x)    # this is a function
    return inverse_cdf

def return_samples(N):
    # let's generate some samples according to the chosen pdf, f(x,y,z)
    uniform_samples_x = random(int(N))
    uniform_samples_y = random(int(N))
    uniform_samples_z = random(int(N))

    required_samples_x = sample(f_x)(uniform_samples_x)    
    required_samples_y = sample(f_y)(uniform_samples_y)
    required_samples_z = sample(f_z)(uniform_samples_z)

    required_samples = np.column_stack((required_samples_x,required_samples_y, required_samples_z))
    print(required_samples.shape)

    return required_samples


## plot
x = np.linspace(0,2*np.pi,10000)
y = np.linspace(0,2*np.pi,10000)
z = np.linspace(0,2*np.pi,10000)

fig, axes = plt.subplots(figsize=(14, 3), ncols=3, nrows=1)

return_xyz = return_samples(2e4)
# x direction
axes[0].set_xlabel('x')
axes[0].set_ylabel('probability density')
axes[0].plot(x,f_x(x)/np.sum(f_x(x)*(x[1]-x[0])) )
axes[0].hist(return_xyz[:,0],bins='auto',density=True,range=(x.min(),x.max()))


# y direction
axes[1].set_xlabel('y')
axes[1].set_ylabel('probability density')
axes[1].plot(y,f_y(y)/np.sum(f_y(y)*(y[1]-y[0])) )
axes[1].hist(return_xyz[:,1],bins='auto',density=True,range=(y.min(),y.max()))

# z direction
axes[2].set_xlabel('z')
axes[2].set_ylabel('probability density')
axes[2].plot(z,f_z(z)/np.sum(f_z(z)*(z[1]-z[0])) )
axes[2].hist(return_xyz[:,2],bins='auto',density=True,range=(z.min(),z.max()))

plt.show() 
plt.savefig('inverse.png')


savedir = 'data/initial/'
make_folder(savedir)
filename = 'initial_2'
## Saving validation results vs epoch to .npy file  
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, return_xyz)