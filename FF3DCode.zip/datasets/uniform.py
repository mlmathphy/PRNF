import numpy as np
import datasets



class UNIFORM:

    class Data:

        def __init__(self, data):

            self.x = data.astype(np.float)
            self.N = self.x.shape[0]

    def __init__(self):
        
        test = load_data()

        self.test = self.Data(test)

        self.n_dims = self.test.x.shape[1]

def load_data():

    # normalization
    with open(datasets.root + 'ff3d/data_mean_std.npy', 'rb') as f:
        mu = np.load(f)
        s = np.load(f)
    
    test = np.load(datasets.root + 'ff3d/valid_uniform.npy')
    test = (test - mu)/s
    return test

    

