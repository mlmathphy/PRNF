root = 'data/'

from .ff3d import *
from .initial1 import *
from .initial2 import *
from .initialgrid import *
from .uniform import *