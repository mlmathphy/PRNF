import numpy as np
import datasets



class INITIALGrid:

    class Data:

        def __init__(self, data):

            self.x = data.astype(np.float64)
            self.N = self.x.shape[0]

    def __init__(self, name):
        
        test = load_data(name)

        self.test = self.Data(test)

        self.n_dims = self.test.x.shape[1]

def load_data(name):

    # normalization
    with open(datasets.root + 'ff3d/data_mean_std.npy', 'rb') as f:
        mu = np.load(f)
        s = np.load(f)
    
    test = np.load(datasets.root + 'initial/' + name +'.npy')
    test = (test - mu[0:3])/s[0:3]
    return test

    

