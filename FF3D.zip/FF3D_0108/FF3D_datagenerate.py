
import numpy as np
# from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from scipy.stats import norm
import os
import scipy.io

seed = 12345
np.random.seed(seed)

root_initial = 'data/initial/'     # where initial condition data
root_data = 'data/'       # where the datasets are


def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)



def drift_3d(Ns, dim, x, y, z):

    drift = np.zeros((Ns, dim)) # (x, y, z)
    P_e = 3
    A = 1
    B = 1
    C = 0.25

    drift[:,0] = P_e * ( A * np.sin(z) + C * np.cos(y) )
    drift[:,1] = P_e * ( B * np.sin(x) + A * np.cos(z) )
    drift[:,2] = P_e * ( C * np.sin(y) + B * np.cos(x) )

    return drift



def diffusion_3d(Ns, dim, x, y, z):

    diff = np.ones((Ns, dim)) # (x, y, z)

    return diff


def FF_3dfun(Ns, train):
    dim = 3
    b_min = 0
    b_max = 2 * np.pi

    if train:
        ## initial positions (uniform distribution (default))
        xyz_min = [b_min, b_min, b_min]   
        xyz_max = [b_max, b_max, b_max]
        X0 = np.random.uniform(low=xyz_min, high=xyz_max, size=(Ns,dim)) # uniformly generate the initial positions, (x,y,z)

    else:
        ## initial positions (artifical distribution, e.g., maxwell)

        # xyz_min = [b_min, b_min, b_min]   
        # xyz_max = [b_max, b_max, b_max]
        # X0 = np.random.uniform(low=xyz_min, high=xyz_max, size=(Ns,dim)) # uniformly generate the initial positions, (x,y,z)


        filename = root_initial + 'initial_1.npy'
        X0 = np.load(filename)

    ## particle pusher (MC method)
    T = 2   # terminal time
    dt = 0.002
    Nt = int(np.floor(T/dt) + 1)
    X_path = np.zeros((Ns, dim, Nt),dtype=float)
    X_path[:,:,0] = X0

    for ii in range(1,Nt):
        if ii % 100 == 0:
            print(ii, Nt)

        Wt = np.random.normal(0, 1, size=(Ns, dim))
        drift_term = drift_3d(Ns, dim, X_path[:,0,ii-1], X_path[:,1,ii-1], X_path[:,2,ii-1])
        diff_term = diffusion_3d(Ns, dim, X_path[:,0,ii-1], X_path[:,1,ii-1], X_path[:,2,ii-1])

        X_path[:,:,ii] = X_path[:,:,ii-1] + drift_term * dt + diff_term * np.sqrt(dt) * Wt

    y = np.column_stack((X0, X_path[:,:,-1]))
    return y





# ------------------------------------------------
#                The main routine
# ------------------------------------------------
savedir = 'data/ff3d/'
make_folder(savedir)

# The dimension of input parameterspace
NV = 5000


# # -------------Generate training data-------------
# y_train = FF_3dfun(8*NV, True)        #(x_0,y_0,z_0,x_T,y_T,z_T)

# # figures x-y
# fig = plt.figure(1, figsize=(8, 12))
# ax = fig.add_subplot(3, 2, 1)
# plt.ion()
# plt.show()

# ax1 = fig.add_subplot(3, 2, 2)
# plt.ion()
# plt.show()

# ax.cla()      
# ax.scatter(y_train[:,1], y_train[:,0], marker='.',alpha=0.2, s=1.)
# ax.set_xlabel('y')
# ax.set_ylabel('x')   
# ax.set_title('initial positions')

# ax1.cla()      
# ax1.scatter(y_train[:,4], y_train[:,3], marker='.',alpha=0.2, s=1.)
# ax1.set_xlabel('y')
# ax1.set_ylabel('x')  
# ax1.set_title('terminal positions')


# # figure x-z
# ax2 = fig.add_subplot(3, 2, 3)
# plt.ion()
# plt.show()

# ax3 = fig.add_subplot(3, 2, 4)
# plt.ion()
# plt.show()

# ax2.cla()      
# ax2.scatter(y_train[:,2], y_train[:,0], marker='.',alpha=0.2, s=1.)
# ax2.set_xlabel('z')
# ax2.set_ylabel('x')   
# ax2.set_title('initial positions')

# ax3.cla()      
# ax3.scatter(y_train[:,5], y_train[:,3], marker='.',alpha=0.2, s=1.)
# ax3.set_xlabel('z')
# ax3.set_ylabel('x')  
# ax3.set_title('terminal positions')


# # figure y-z
# ax4 = fig.add_subplot(3, 2, 5)
# plt.ion()
# plt.show()

# ax5 = fig.add_subplot(3, 2, 6)
# plt.ion()
# plt.show()

# ax4.cla()      
# ax4.scatter(y_train[:,2], y_train[:,1], marker='.',alpha=0.2, s=1.)
# ax4.set_xlabel('z')
# ax4.set_ylabel('y')   
# ax4.set_title('initial positions')

# ax5.cla()      
# ax5.scatter(y_train[:,5], y_train[:,4], marker='.',alpha=0.2, s=1.)
# ax5.set_xlabel('z')
# ax5.set_ylabel('y')  
# ax5.set_title('terminal positions')

# plt.savefig(savedir + '/data_B1C025T2' + '.pdf', dpi='figure')

# ## Saving validation results vs epoch to .npy file  
# with open(savedir + '/data_B1C025T2.npy', 'wb') as f:
#     np.save(f, y_train)

# ## save mu and std
# mu = y_train.mean(axis=0)
# s = y_train.std(axis=0)

# print(mu.shape)
# with open(root_data + 'ff3d/data_mean_std.npy', 'wb') as f:
#     np.save(f, mu)
#     np.save(f, s)

# exit()











# -------------Generate testing data-------------
# The number of testing set
NTest = 4*NV
#
y_valid = FF_3dfun(NTest, False)

filename = 'test_initial_1'
# filename = 'valid_uniform'


# figures x-y
fig = plt.figure(1, figsize=(8, 12))
ax = fig.add_subplot(3, 2, 1)
plt.ion()
plt.show()

ax1 = fig.add_subplot(3, 2, 2)
plt.ion()
plt.show()

ax.cla()      
ax.scatter(y_valid[:,1], y_valid[:,0], marker='.',alpha=0.2, s=1.)
ax.set_xlabel('y')
ax.set_ylabel('x')   
ax.set_title('initial positions')

ax1.cla()      
ax1.scatter(y_valid[:,4], y_valid[:,3], marker='.',alpha=0.2, s=1.)
ax1.set_xlabel('y')
ax1.set_ylabel('x')  
ax1.set_title('terminal positions')

# figure x-z
ax2 = fig.add_subplot(3, 2, 3)
plt.ion()
plt.show()

ax3 = fig.add_subplot(3, 2, 4)
plt.ion()
plt.show()

ax2.cla()      
ax2.scatter(y_valid[:,2], y_valid[:,0], marker='.',alpha=0.2, s=1.)
ax2.set_xlabel('z')
ax2.set_ylabel('x')   
ax2.set_title('initial positions')

ax3.cla()      
ax3.scatter(y_valid[:,5], y_valid[:,3], marker='.',alpha=0.2, s=1.)
ax3.set_xlabel('z')
ax3.set_ylabel('x')  
ax3.set_title('terminal positions')


# figure y-z
ax4 = fig.add_subplot(3, 2, 5)
plt.ion()
plt.show()

ax5 = fig.add_subplot(3, 2, 6)
plt.ion()
plt.show()

ax4.cla()      
ax4.scatter(y_valid[:,2], y_valid[:,1], marker='.',alpha=0.2, s=1.)
ax4.set_xlabel('z')
ax4.set_ylabel('y')   
ax4.set_title('initial positions')

ax5.cla()      
ax5.scatter(y_valid[:,5], y_valid[:,4], marker='.',alpha=0.2, s=1.)
ax5.set_xlabel('z')
ax5.set_ylabel('y')  
ax5.set_title('terminal positions')


plt.savefig(savedir + filename + '.pdf', dpi='figure')

## Saving validation results vs epoch to .npy file  
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, y_valid)

exit()






















