import numpy as np
import matplotlib.pyplot as plt



## dataset name: 
#---------------
data_name  = 'train_result/valid_loss'
filename = data_name+  '.npy'

with open(filename, 'rb') as f:
    valida_loss = np.load(f)
print('data name:' + data_name)
print(valida_loss.shape)

epoch = valida_loss[:,0]
total_loss = valida_loss[:,1]
loss_1 = valida_loss[:,2]
loss_2 = valida_loss[:,3]
loss_3 = valida_loss[:,4]


# plots
fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
ax.semilogx(epoch[1:], loss_1[1:] + loss_2[1:],color="red")
ax.set_ylabel("- log P",
              color="red",
              fontsize=14)
# set x-axis label
ax.set_xlabel("epoch", fontsize = 14)
# set y-axis label
# ax.set_ylabel("lifeExp",
#               color="red",
#               fontsize=14)

# twin object for two different y-axis on the sample plot
ax2=ax.twinx()
# make a plot with different y-axis using second axis object
ax2.semilogx(epoch[1:], loss_3[1:],color="blue")
ax2.set_ylabel("reversibility loss",color="blue",fontsize=14)
plt.grid(True, which="both")
plt.show()
plt.savefig('validLoss.png', dpi=150, bbox_inches='tight')


exit()

