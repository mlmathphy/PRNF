
import numpy as np
import matplotlib.pyplot as plt
import datasets
from scipy.stats import gaussian_kde
from scipy.stats import norm
from matplotlib.gridspec import SubplotSpec
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'eval_result/'


def create_subtitle(fig: plt.Figure, grid: SubplotSpec, title: str):
    "Sign sets of subplots with title"
    row = fig.add_subplot(grid)
    # the '\n' is important
    row.set_title(f'{title}\n', fontweight='semibold')
    # hide subplot
    row.set_frame_on(False)
    row.axis('off')


# filename = savedir + 'valid_uniform'
filename = savedir + 'test_initial2'
with open(filename + '.npy', 'rb') as f:
    y_test = np.load(f)     # (p,xi)
    y_pred = np.load(f)


## data normaized back and periodic boundary condition:
with open(datasets.root + 'ff3d/data_mean_std.npy', 'rb') as f:
    mu = np.load(f)
    s = np.load(f)
    
dim = 3
y_test = y_test * s[dim:] + mu[dim:]
y_pred = y_pred * s[dim:] + mu[dim:]


rows = 3
cols = 3
fig, axes = plt.subplots(rows, cols, figsize=(12, 12))
grid = plt.GridSpec(rows, cols)
create_subtitle(fig, grid[0, ::], '1D marginal pdf')
create_subtitle(fig, grid[1, ::], '2D marginal pdf by PRNF')
create_subtitle(fig, grid[2, ::], '2D marginal pdf by MC')
#-----------------pred--------------
data_type = 'pred'
## plotting prediction
x = y_pred[:,0]
y = y_pred[:,1]
z = y_pred[:,2]


xkde = gaussian_kde(x)
ind = np.linspace(np.min(x),np.max(x),51)
kdepdf_x = xkde.evaluate(ind)
axes[0,0].plot(ind, kdepdf_x, label='PRNF', color="r")
axes[0,0].set_xlim(-5,15)

ykde = gaussian_kde(y)
ind = np.linspace(np.min(y),np.max(y),51)
kdepdf_y = ykde.evaluate(ind)
axes[0,1].plot(ind, kdepdf_y, label='PRNF', color="r")
axes[0,1].set_xlim(-10,10)

zkde = gaussian_kde(z)
ind = np.linspace(np.min(z),np.max(z),51)
kdepdf_z = zkde.evaluate(ind)
axes[0,2].plot(ind, kdepdf_z, label='PRNF', color="r")
axes[0,2].set_xlim(-6,14)


# Define the borders
deltaX = (max(x) - min(x))/100
deltaY = (max(y) - min(y))/100
deltaZ = (max(z) - min(z))/100
xmin = min(x) - deltaX
xmax = max(x) + deltaX
ymin = min(y) - deltaY
ymax = max(y) + deltaY
zmin = min(z) - deltaZ
zmax = max(z) + deltaZ



# Create meshgrid
xx, yy = np.mgrid[xmin:xmax:50j, ymin:ymax:50j]
positions = np.vstack([xx.ravel(), yy.ravel()])
values = np.vstack([x, y])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.03]
cfset = axes[1,0].contourf(xx, yy, f, levels=levels, cmap='coolwarm')
cset = axes[1,0].contour(xx, yy, f, levels=levels, colors='k')
axes[1,0].clabel(cset, inline=1, fontsize=10)
axes[1,0].set_xlabel('x axis')
axes[1,0].set_ylabel('y axis')
axes[1,0].set_xlim(-3,12)
axes[1,0].set_ylim(-13,8)

# Create meshgrid
xx, zz = np.mgrid[xmin:xmax:50j, zmin:zmax:50j]
positions = np.vstack([xx.ravel(), zz.ravel()])
values = np.vstack([x, z])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
# Plotting the kernel with annotated contours
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.04,0.06]
cfset = axes[1,1].contourf(xx, zz, f, levels=levels, cmap='coolwarm')
cset = axes[1,1].contour(xx, zz, f, levels=levels, colors='k')
axes[1,1].clabel(cset, inline=1, fontsize=10)
axes[1,1].set_xlabel('x axis')
axes[1,1].set_ylabel('z axis')
axes[1,1].set_xlim(-4,13)
axes[1,1].set_ylim(-6,12)


# Create meshgrid
zz, yy = np.mgrid[zmin:zmax:50j, ymin:ymax:50j]
positions = np.vstack([zz.ravel(), yy.ravel()])
values = np.vstack([z, y])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, zz.shape)
# Plotting the kernel with annotated contours
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.03]
cfset = axes[1,2].contourf(zz, yy, f, levels=levels, cmap='coolwarm')
cset = axes[1,2].contour(zz, yy, f, levels=levels, colors='k')
axes[1,2].clabel(cset, inline=1, fontsize=10)
axes[1,2].set_xlabel('z axis')
axes[1,2].set_ylabel('y axis')
axes[1,2].set_xlim(-5,11)
axes[1,2].set_ylim(-12,8)

# #-----------------test--------------
data_type = 'test'
## plotting prediction
x = y_test[:,0]
y = y_test[:,1]
z = y_test[:,2]


xkde = gaussian_kde(x)
ind = np.linspace(np.min(x),np.max(x),51)
kdepdf_x = xkde.evaluate(ind)
axes[0,0].plot(ind, kdepdf_x, label='MC', color="b")
axes[0,0].set_xlabel('x axis')
axes[0,0].set_ylabel('density')


ykde = gaussian_kde(y)
ind = np.linspace(np.min(y),np.max(y),51)
kdepdf_y = ykde.evaluate(ind)
axes[0,1].plot(ind, kdepdf_y, label='MC', color="b")
axes[0,1].set_xlabel('y axis')
axes[0,1].set_ylabel('density')


zkde = gaussian_kde(z)
ind = np.linspace(np.min(z),np.max(z),51)
kdepdf_z = zkde.evaluate(ind)
axes[0,2].plot(ind, kdepdf_z, label='MC', color="b")
axes[0,2].set_xlabel('z axis')
axes[0,2].set_ylabel('density')


axes[0,0].legend()
axes[0,1].legend()
axes[0,2].legend()

# Define the borders
deltaX = (max(x) - min(x))/100
deltaY = (max(y) - min(y))/100
deltaZ = (max(z) - min(z))/100
xmin = min(x) - deltaX
xmax = max(x) + deltaX
ymin = min(y) - deltaY
ymax = max(y) + deltaY
zmin = min(z) - deltaZ
zmax = max(z) + deltaZ



# Create meshgrid
xx, yy = np.mgrid[xmin:xmax:50j, ymin:ymax:50j]
positions = np.vstack([xx.ravel(), yy.ravel()])
values = np.vstack([x, y])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
f = np.minimum(f,0.03)
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.03]
cfset = axes[2,0].contourf(xx, yy, f, levels=levels, cmap='coolwarm')
cset = axes[2,0].contour(xx, yy, f, levels=levels, colors='k')
axes[2,0].clabel(cset, inline=1, fontsize=10)
axes[2,0].set_xlabel('x axis')
axes[2,0].set_ylabel('y axis')
axes[2,0].set_xlim(-3,12)
axes[2,0].set_ylim(-13,8)


# Create meshgrid
xx, zz = np.mgrid[xmin:xmax:50j, zmin:zmax:50j]
positions = np.vstack([xx.ravel(), zz.ravel()])
values = np.vstack([x, z])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.04,0.06]
cfset = axes[2,1].contourf(xx, zz, f, levels=levels, cmap='coolwarm')
cset = axes[2,1].contour(xx, zz, f, levels=levels, colors='k')
axes[2,1].clabel(cset, inline=1, fontsize=10)
axes[2,1].set_xlabel('x axis')
axes[2,1].set_ylabel('z axis')
axes[2,1].set_xlim(-4,13)
axes[2,1].set_ylim(-6,12)


# Create meshgrid
zz, yy = np.mgrid[zmin:zmax:50j, ymin:ymax:50j]
positions = np.vstack([zz.ravel(), yy.ravel()])
values = np.vstack([z, y])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, zz.shape)
# Plotting the kernel with annotated contours
f = np.minimum(f,0.03)
levels = [0,0.001,0.002,0.003,0.004,0.005,0.01,0.02,0.03]
cfset = axes[2,2].contourf(zz, yy, f, levels=levels, cmap='coolwarm')
cset = axes[2,2].contour(zz, yy, f, levels=levels, colors='k')
axes[2,2].clabel(cset, inline=1, fontsize=10)
axes[2,2].set_xlabel('z axis')
axes[2,2].set_ylabel('y axis')
axes[2,2].set_xlim(-5,11)
axes[2,2].set_ylim(-12,8)


plt.tight_layout()
plt.show()
plt.savefig(filename + '_contour.png', dpi='figure')
 
