
import numpy as np
import matplotlib.pyplot as plt
import datasets
from scipy.stats import gaussian_kde
from scipy.stats import norm
from matplotlib.gridspec import SubplotSpec
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'eval_result/'



# ########### step 1############# 
# int_x_min = -1.5 * np.pi
# int_x_max = -0.5 * np.pi
# int_z_min = np.pi
# int_z_max = 2.0 * np.pi
# density_value = np.empty((0,3), float)


# for x_i in range(12):
#     for z_i in range(12):
#         print(x_i)
#         filename = savedir + "density_%d_%d" %(x_i,z_i)
#         with open(filename + '.npy', 'rb') as f:
#             y_pred = np.load(f)


#         ## data normaized back and periodic boundary condition:
#         with open(datasets.root + 'ff3d/data_mean_std.npy', 'rb') as f:
#             mu = np.load(f)
#             s = np.load(f)
            
#         dim = 3
#         y_pred = y_pred * s[dim:] + mu[dim:]

#         ## plotting prediction
#         x = y_pred[:,0]
#         y = y_pred[:,1]
#         z = y_pred[:,2]

#         values = np.vstack([x, z])
#         kernel = gaussian_kde(values)

#         # Define the borders
#         deltaX = (max(x) - min(x))/100
#         deltaY = (max(y) - min(y))/100
#         deltaZ = (max(z) - min(z))/100
#         xmin = min(x) - deltaX
#         xmax = max(x) + deltaX
#         ymin = min(y) - deltaY
#         ymax = max(y) + deltaY
#         zmin = min(z) - deltaZ
#         zmax = max(z) + deltaZ

#         # whole domain
#         xx, zz = np.mgrid[xmin:xmax:100j, zmin:zmax:100j]
#         positions = np.vstack([xx.ravel(), zz.ravel()])
#         f = kernel(positions)
#         density_all = np.sum(f) * (zz[0,1] - zz[0,0]) * (xx[1,0] - xx[0,0])
#         print(density_all)

#         xx, zz = np.mgrid[int_x_min:int_x_max:50j, int_z_min:int_z_max:50j]
#         positions = np.vstack([xx.ravel(), zz.ravel()])
#         f = kernel(positions)
#         density_partial = np.sum(f) * (zz[0,1] - zz[0,0]) * (xx[1,0] - xx[0,0])
#         density = density_partial / density_all

#         x_0 = x_i / 11.0 * 2.0 * np.pi
#         z_0 = x_i / 11.0 * 2.0 * np.pi

#         print(density)

#         density_value = np.append(density_value, [[x_0, z_0, density]], axis=0)

# with open('density_grid.npy', 'wb') as f:
#     np.save(f, density_value)
# exit()



rows = 1
cols = 1
fig, axes = plt.subplots(rows, cols, figsize=(4, 4))

with open('density_grid.npy', 'rb') as f:
    density_value = np.load(f)


# Plotting the kernel with annotated contours
xx, zz = np.mgrid[0:2.0 * np.pi:12j, 0:2.0 * np.pi:12j]

density_data = density_value[:,2]
density_data_reshape = np.reshape(density_data.T, xx.shape)


levels = np.linspace(np.min(density_data),np.max(density_data),10)
cfset = axes.contourf(xx, zz, density_data_reshape, levels=levels, cmap='coolwarm')
cset = axes.contour(xx, zz, density_data_reshape, levels=levels, colors='k')
axes.clabel(cset, inline=1, fontsize=10)
axes.set_xlabel('$x_0$')
axes.set_ylabel('$z_0$')


plt.tight_layout()
plt.show()
plt.savefig('density_contour.png', dpi='figure')
 
