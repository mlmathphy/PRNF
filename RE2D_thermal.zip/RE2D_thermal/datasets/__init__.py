root = 'data/'

from .re2d import *
from .maxd1 import *
from .maxd2 import *
from .maxd3 import *
from .maxd4 import *
from .maxd5 import *
from .maxd6 import *
from .maxd7 import *
from .maxd8 import *
from .maxd9 import *
from .maxd10 import *
from .uniform import *