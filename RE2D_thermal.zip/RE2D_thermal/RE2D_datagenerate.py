
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
import os
import scipy.io

seed = 12345
np.random.seed(seed)

root_initial = 'data/initalMaxwell/'     # where initial maxwell data
root_data = 'data/'       # where the datasets are


def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)



def drift_2d(Ns, dim, p, xi):

    drift = np.zeros((Ns, dim)) # (p,xi,r)
    Z = 1.0
    E0 = 0.0005
    tau = 6000.0
    T_tilde = 3
    mc2 = 500.0
    Tf_hat = 0.05

    delta_tilde = np.sqrt(2 * T_tilde / mc2)
    delta = np.sqrt(2 * Tf_hat / mc2)

    vT_bar = np.sqrt(Tf_hat / T_tilde)

    lnA_hat = 14.9 - 1/2 * np.log(0.28) + np.log(Tf_hat)
    lnA_tilde = 14.9 - 1/2 * np.log(0.28) + np.log(T_tilde)
    vee_bar = (T_tilde / Tf_hat)**(3/2) * lnA_hat / lnA_tilde
    E = E0 * (T_tilde / Tf_hat)**(3/2)


    gamma = np.sqrt( 1 + (delta_tilde * p)**2 )
    xx = 1 / vT_bar * p / gamma

    phi = norm.cdf(xx, 0, np.sqrt(0.5)) - norm.cdf(-xx, 0, np.sqrt(0.5))
    psi = 1 / (2 * xx**2) * ( phi - xx * (2 / np.sqrt(np.pi)) * np.exp( -xx**2 ) )

    ca = vee_bar * vT_bar**2 * psi / xx
    cb = 0.5 * vee_bar * vT_bar**2 * ( Z + phi - psi + delta**4 * xx**2 * 0.5 ) / xx
    cf = 2 * vee_bar * vT_bar * psi
    ca = np.maximum(ca, 1e-10)
    cb = np.maximum(cb, 1e-10)

    dp = 0.001
    p1 = p + dp
    gamma_p1 = np.sqrt( 1 + (delta_tilde * p1)**2 )
    xx_p1 = 1 / vT_bar * p1 / gamma_p1

    phi_p1 = norm.cdf(xx_p1, 0, np.sqrt(0.5)) - norm.cdf(-xx_p1, 0, np.sqrt(0.5))
    psi_p1 = 1 / (2 * xx_p1**2) * ( phi_p1 - xx_p1 * (2 / np.sqrt(np.pi)) * np.exp( -xx_p1**2 ) )

    CA_p1 = vee_bar * vT_bar**2 * psi_p1 / xx_p1
    CA_p1 = np.maximum(CA_p1, 1e-10)

    drift[:,0] = E * xi - gamma * p / tau * (1-xi**2) - cf + 2/p * ca + (CA_p1 - ca)/dp
    drift[:,1] = E * (1-xi**2) / p + xi * (1-xi**2)/tau/gamma - 2*xi * cb / p**2

    return drift



def diffusion_2d(Ns, dim, p, xi):

    diff = np.zeros((Ns, dim)) # (p,xi,r)
    Z = 1.0
    T_tilde = 3
    mc2 = 500.0
    Tf_hat = 0.05

    delta_tilde = np.sqrt(2 * T_tilde / mc2)
    delta = np.sqrt(2 * Tf_hat / mc2)

    vT_bar = np.sqrt(Tf_hat / T_tilde)

    lnA_hat = 14.9 - 1/2 * np.log(0.28) + np.log(Tf_hat)
    lnA_tilde = 14.9 - 1/2 * np.log(0.28) + np.log(T_tilde)
    vee_bar = (T_tilde / Tf_hat)**(3/2) * lnA_hat / lnA_tilde

    gamma = np.sqrt( 1 + (delta_tilde * p)**2 )
    xx = 1 / vT_bar * p / gamma

    phi = norm.cdf(xx, 0, np.sqrt(0.5)) - norm.cdf(-xx, 0, np.sqrt(0.5))
    psi = 1 / (2 * xx**2) * ( phi - xx * (2 / np.sqrt(np.pi)) * np.exp( -xx**2 ) )

    ca = vee_bar * vT_bar**2 * psi / xx
    cb = 0.5 * vee_bar * vT_bar**2 * ( Z + phi - psi + delta**4 * xx**2 * 0.5 ) / xx
    ca = np.maximum(ca, 1e-10)
    cb = np.maximum(cb, 1e-10)

    diff[:,0] = np.sqrt(2*ca)
    diff[:,1] = np.sqrt(2*cb) * np.sqrt( 1-xi**2 ) / p

    return diff


def RE_2dfun(Ns, train, p_min, p_max):
    dim = 2
    ## data is given by [momentum p, cosine of pitch angle xi, minor radius r]

    if train:
        ## initial positions (uniform distribution (default))
        px_min = [p_min, -1]   
        px_max = [p_max, 1]
        X0 = np.random.uniform(low=px_min, high=px_max, size=(Ns,dim)) # uniformly generate the initial positions, (p,xi,r)

    else:
        ## initial positions (artifical distribution, e.g., maxwell)

        # pxr_min = [p_min, -1, 0]   
        # pxr_max = [p_max, 1, 1]
        # X0 = np.random.uniform(low=pxr_min, high=pxr_max, size=(Ns,dim)) # uniformly generate the initial positions, (p,xi,r)


        filename = root_initial + 'RE2DInitial_maxwell_delta9.mat'
        mat = scipy.io.loadmat(filename)
        X0 = mat['Y_all']


    ## particle pusher (MC method)
    T = 26   # terminal time
    dt = 0.005
    Nt = int(np.floor(T/dt) + 1)
    X_path = np.zeros((Ns, dim, Nt),dtype=float)
    X_path[:,:,0] = X0

    for ii in range(1,Nt):
        if ii % 100 == 0:
            print(ii, Nt)

        Wt = np.random.normal(0, 1, size=(Ns, dim))
        drift_term = drift_2d(Ns, dim, X_path[:,0,ii-1], X_path[:,1,ii-1])
        diff_term = diffusion_2d(Ns, dim, X_path[:,0,ii-1], X_path[:,1,ii-1])

        X_path[:,:,ii] = X_path[:,:,ii-1] + drift_term * dt + diff_term * np.sqrt(dt) * Wt

        ## period boundary condition for xi
        X_path[X_path[:,1,ii] >= 1,1, ii] = X_path[X_path[:,1,ii] >= 1,1, ii] - 2*(X_path[X_path[:,1,ii] >= 1,1, ii] - 1)
        X_path[X_path[:,1,ii] <= -1,1, ii] = X_path[X_path[:,1,ii] <= -1,1, ii] + 2*( -1- X_path[X_path[:,1,ii] <= -1,1, ii])

        X_path[X_path[:,0,ii] < p_min, 0, ii] = p_min

        ##check for p below than 0
        if np.any(X_path[:,0, ii] <= 0):
            raise ValueError('negative momentum')

    y = np.column_stack((X0, X_path[:,:,-1]))
    return y





# ------------------------------------------------
#                The main routine
# ------------------------------------------------
savedir = 'data/re2d/'
make_folder(savedir)

# The dimension of input parameterspace
NV = 5000


# # -------------Generate training data-------------
# y_train_1 = RE_2dfun(1*NV, True, 0.5, 5)        #(p_0,xi_0,p_T,xi_T)
# y_train_2 = RE_2dfun(3*NV, True, 0.5, 3)        #(p_0,xi_0,p_T,xi_T)

# y_train = np.vstack((y_train_1, y_train_2)) 
# rng = np.random.RandomState(42)
# rng.shuffle(y_train)


# # figures
# fig = plt.figure(1, figsize=(10, 5))
# ax = fig.add_subplot(1, 2, 1)
# plt.ion()
# plt.show()

# ax1 = fig.add_subplot(1, 2, 2)
# plt.ion()
# plt.show()


# ax.cla()      
# ax.scatter(y_train[:,1], y_train[:,0], marker='.',alpha=0.2, s=1.)
# ax.set_xlabel('cos of pitch angle')
# ax.set_xlim(-1,1)
# ax.set_ylabel('p')   
# ax.set_title('initial positions')

# ax1.cla()      
# ax1.scatter(y_train[:,3], y_train[:,2], marker='.',alpha=0.2, s=1.)
# ax1.set_xlabel('cos of pitch angle')
# ax1.set_xlim(-1,1)
# ax1.set_ylabel('p')  
# ax1.set_title('terminal positions')

# plt.savefig(savedir + '/data' + '.pdf', dpi='figure')

# ## Saving validation results vs epoch to .npy file  
# with open(savedir + '/data.npy', 'wb') as f:
#     np.save(f, y_train)

# ## save mu and std
# mu = y_train.mean(axis=0)
# s = y_train.std(axis=0)

# print(mu.shape)
# with open(root_data + 're2d/data_mean_std.npy', 'wb') as f:
#     np.save(f, mu)
#     np.save(f, s)

# exit()











# -------------Generate testing data-------------
# The number of testing set
NTest = 4*NV
#
y_valid = RE_2dfun(NTest, False, 0.5, 5)

filename = 'maxwell_delta9'
# filename = 'valid_uniform'

# figures
fig = plt.figure(1, figsize=(10, 5))
ax = fig.add_subplot(1, 2, 1)
plt.ion()
plt.show()

ax1 = fig.add_subplot(1, 2, 2)
plt.ion()
plt.show()


ax.cla()      
ax.scatter(y_valid[:,1], y_valid[:,0], marker='.',alpha=0.2, s=1.)
ax.set_xlabel('cos of pitch angle')
ax.set_xlim(-1,1)
ax.set_ylabel('p')   
ax.set_title('initial positions')

ax1.cla()      
ax1.scatter(y_valid[:,3], y_valid[:,2], marker='.',alpha=0.2, s=1.)
ax1.set_xlabel('cos of pitch angle')
ax1.set_xlim(-1,1)
ax1.set_ylabel('p')  
ax1.set_title('terminal positions')

plt.savefig(savedir + filename + '.pdf', dpi='figure')

## Saving validation results vs epoch to .npy file  
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, y_valid)

exit()






















