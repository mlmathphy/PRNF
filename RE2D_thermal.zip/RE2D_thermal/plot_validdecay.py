import numpy as np
import matplotlib.pyplot as plt


fig = plt.figure(figsize=(8, 2.5))

## lambda = 1
## dataset name: 
#---------------
data_name  = 'train_result/lambda1_valid_loss'
filename = data_name+  '.npy'

with open(filename, 'rb') as f:
    valida_loss = np.load(f)
print('data name:' + data_name)
print(valida_loss.shape)

epoch = valida_loss[:,0]
total_loss = valida_loss[:,1]
loss_1 = valida_loss[:,2]
loss_2 = valida_loss[:,3]
loss_3 = valida_loss[:,4]

# plots
ax = fig.add_subplot(1, 3, 1)
ax.semilogx(epoch[1:], loss_1[1:] + loss_2[1:],color="red")
ax.set_ylabel("$\mathcal{L}_1$",
              color="red",
              fontsize=10)
# set x-axis label
ax.set_xlabel("epoch", fontsize = 6)
# set y-axis label
ax1=ax.twinx()
# make a plot with different y-axis using second axis object
ax1.semilogx(epoch[1:], loss_3[1:],color="blue")
ax1.set_ylabel("$\mathcal{L}_2$",color="blue",fontsize=10)

ax.tick_params(axis='both', which='major', labelsize=6)
ax.set_title('$\lambda = 1$', fontsize = 8)
ax1.tick_params(axis='both', which='major', labelsize=6)
plt.grid(True, which="both")


## lambda = 100
## dataset name: 
#---------------
data_name  = 'train_result/valid_loss'
filename = data_name+  '.npy'

with open(filename, 'rb') as f:
    valida_loss = np.load(f)
print('data name:' + data_name)
print(valida_loss.shape)

epoch = valida_loss[:,0]
total_loss = valida_loss[:,1]
loss_1 = valida_loss[:,2]
loss_2 = valida_loss[:,3]
loss_3 = valida_loss[:,4]

# plots
ax2 = fig.add_subplot(1, 3, 2)
ax2.semilogx(epoch[1:], loss_1[1:] + loss_2[1:],color="red")
ax2.set_ylabel("$\mathcal{L}_1$",
              color="red",
              fontsize=10)
# set x-axis label
ax2.set_xlabel("epoch", fontsize = 6)
ax2.set_title('$\lambda = 100$', fontsize = 8)
# set y-axis label
ax3=ax2.twinx()
# make a plot with different y-axis using second axis object
ax3.semilogx(epoch[1:], loss_3[1:],color="blue")
ax3.set_ylabel("$\mathcal{L}_2$",color="blue",fontsize=10)
ax2.tick_params(axis='both', which='major', labelsize=6)
ax3.tick_params(axis='both', which='major', labelsize=6)
plt.grid(True, which="both")




## lambda = 1000
## dataset name: 
#---------------
data_name  = 'train_result/lambda1000_valid_loss'
filename = data_name+  '.npy'

with open(filename, 'rb') as f:
    valida_loss = np.load(f)
print('data name:' + data_name)
print(valida_loss.shape)

epoch = valida_loss[:,0]
total_loss = valida_loss[:,1]
loss_1 = valida_loss[:,2]
loss_2 = valida_loss[:,3]
loss_3 = valida_loss[:,4]

# plots
ax4 = fig.add_subplot(1, 3, 3)
ax4.semilogx(epoch[1:], loss_1[1:] + loss_2[1:],color="red")
ax4.set_ylabel("$\mathcal{L}_1$",
              color="red",
              fontsize=10)
# set x-axis label
ax4.set_xlabel("epoch", fontsize = 6)
ax4.set_title('$\lambda = 1000$', fontsize = 8)
# set y-axis label
ax5=ax4.twinx()
# make a plot with different y-axis using second axis object
ax5.semilogx(epoch[1:], loss_3[1:],color="blue")
ax5.set_ylabel("$\mathcal{L}_2$",color="blue",fontsize=10)
ax4.tick_params(axis='both', which='major', labelsize=6)
ax5.tick_params(axis='both', which='major', labelsize=6)

fig.tight_layout()

plt.grid(True, which="both")
plt.show()
plt.savefig('validLoss.png', dpi=150, bbox_inches='tight')


exit()

