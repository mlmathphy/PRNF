import sys
import numpy as np
import os
import datasets
import torch
import matplotlib.pyplot as plt
import torch.nn as nn

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)




def load_data():
    return np.load(datasets.root + 're2d/data.npy')


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/'       # where the datasets are

data = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """

    assert isinstance(name, str), 'Name must be a string'
    datasets.root = root_data
    global data, data_name

    if data_name == name:
        return

    elif name == 'maxwell_delta1':
        data = datasets.MAXD1()
        data_name = name

    elif name == 'maxwell_delta2':
        data = datasets.MAXD2()
        data_name = name

    elif name == 'maxwell_delta3':
        data = datasets.MAXD3()
        data_name = name

    elif name == 'maxwell_delta4':
        data = datasets.MAXD4()
        data_name = name

    elif name == 'maxwell_delta5':
        data = datasets.MAXD5()
        data_name = name

    elif name == 'maxwell_delta6':
        data = datasets.MAXD6()
        data_name = name

    elif name == 'maxwell_delta7':
        data = datasets.MAXD7()
        data_name = name

    elif name == 'maxwell_delta8':
        data = datasets.MAXD8()
        data_name = name

    elif name == 'maxwell_delta9':
        data = datasets.MAXD9()
        data_name = name

    elif name == 'maxwell_delta10':
        data = datasets.MAXD10()
        data_name = name

    elif name == 'valid_uniform':
        data = datasets.UNIFORM()
        data_name = name

    else:
        raise ValueError('Unknown dataset')


def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = 'RE2D_PRNF'

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 512

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def backward(self, x, dim):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x




def test_initialGreen(name):

    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    dim = int(data.n_dims / 2)
    print('dimensionality is ', dim)
    try:
        NF = load_model(dim)

    except IOError:
        return 'N/A'



    ## test:
    N_test,_ = data.test.x.shape ## note all data has been normalized
    z_sample0 = np.random.randn(N_test,dim)
    y0 = data.test.x[:,:dim]
    y_test = data.test.x[:,dim:]    # true
    y0z_sample0 = np.column_stack( (y0,z_sample0) )
    y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
    y0_y = NF.backward(y0z_sample, dim)
    y = y0_y[:,dim:2 * dim]

    y_pred = y.to('cpu').detach().numpy()   # approximation
    make_folder(root_results)
    with open(root_results + name + '.npy', 'wb') as f:
        np.save(f, y_test)
        np.save(f, y_pred)

    





def main():

    for initial in sys.argv[1:]:

        if initial == 'maxwell_delta1':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta2':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta3':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta4':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta5':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta6':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta7':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta8':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta9':
            test_initialGreen(initial)

        elif initial == 'maxwell_delta10':
            test_initialGreen(initial)

        elif initial == 'valid_uniform':
            test_initialGreen(initial)

        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
