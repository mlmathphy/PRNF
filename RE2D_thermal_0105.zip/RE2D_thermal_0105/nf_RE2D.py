import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim
import matplotlib.pyplot as plt
import math
import scipy.special as special
import datasets
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'train_result/'



data = None
data_name = None

seed = 12345
torch.manual_seed(seed)
np.random.seed(seed)

def load_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """

    assert isinstance(name, str), 'Name must be a string'
    datasets.root = root_data
    global data, data_name

    if data_name == name:
        return

    if name == 'RE2D':
        data = datasets.RE2D()
        data_name = name


    else:
        raise ValueError('Unknown dataset')

def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None




def save_model(model):
    """
    Save pytorch NN model.
    """
    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    make_folder(savedir)

    filename = 'RE2D_PRNF'
    checkpoint = {'state_dict': model.state_dict()}
    torch.save(checkpoint, savedir + filename + '.pt')




def data_loader(data,batch_size):
    y_trn = torch.as_tensor(data.trn.x,dtype=torch.float,device = device)
    y_val = torch.as_tensor(data.val.x,dtype=torch.float,device = device)

    train_loader = torch.utils.data.DataLoader(dataset=y_trn, 
                                            batch_size=batch_size, 
                                            shuffle=True)
    valid_loader = torch.utils.data.DataLoader(dataset=y_val, 
                                            batch_size=batch_size, 
                                            shuffle=False)
    return train_loader, valid_loader


def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)

    

def jacobian(output, input):

    n, dim= input.shape
    d = int(dim/2)
    w = torch.ones_like(input[:,[0]])

    jacob1 = torch.empty(d, n, 2 * d)
    input1 = input
    output1 = output[:, d:2 * d]
    for i in range(d):
        output1_i = output1[:, [i]]
        jacob1[i] = torch.autograd.grad(output1_i, input1, w, create_graph=True)[0]

    jacob1 = jacob1.permute(1, 0, 2)
    jacob1 = jacob1[:,:,d:2 * d]
    return jacob1


class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 512

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def forward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.input(x))
        x = torch.tanh(self.fc1(x))
        x = self.output(x)
        x = torch.cat((y0, x), 1)
        return x


    def backward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)

        return x


    def get_grad(self, x):
     
        x.requires_grad_(True)
        xx = self.forward(x)
        jac = jacobian(xx,x)
        return jac



def standard_normal_logprob(z):
    logZ = -0.5 * math.log(2 * math.pi)
    return logZ - z.pow(2) / 2


def loss_fun(model, y, dim):
    NF = model.to(device)
    z = NF.forward(y)

    ## loss1: forward loss:
    loss1 = - 1.0 * torch.mean( torch.sum(standard_normal_logprob(z[:,dim:2*dim]), axis = 1, keepdim=False), axis = 0)

    ## loss2: det of jacobian
    jac = torch.abs(torch.linalg.det(NF.get_grad(y)))
    loss2 = -1.0 * torch.mean(torch.log(jac))

    ## loss3: backward loss
    y_pred = NF.backward(z)

    loss3 = torch.mean((y_pred[:,dim] - y[:,dim])**2 + (y_pred[:,dim+1] - y[:,dim+1])**2)
    C_rev = 1
    loss = loss1 * 1.0 + loss2 * 1.0 + loss3 * C_rev
    # print(loss1, loss2, loss3)
    return loss, loss1, loss2, loss3


def eval_logmean(model, dataloader, dim):

    for y_valid in dataloader:
        losses, loss1, loss2, loss3 = loss_fun(model, y_valid, dim)

    return losses, loss1, loss2, loss3



# ------------------------------------------------
#                The main routine
# ------------------------------------------------
load_data('RE2D')
assert is_data_loaded(), 'Dataset hasn\'t been loaded'

dim = int(data.n_dims / 2)
print('dimensionality is ', dim)
batch_size = 5000

NF = NF_Net(dim).to(device)
NF.zero_grad()

# Learning rate
learning_rate = 0.001
optimizer = optim.Adam(NF.parameters(), lr=learning_rate)

train_loader, valid_loader = data_loader(data, batch_size)

# figures
make_folder(savedir)
plt.figure()
plt.style.use('seaborn-colorblind')

# for validation 
N_valid,_ = data.val.x.shape
z_sample0 = np.random.randn(N_valid,dim)
y0 = data.val.x[:,:dim]
y_test = data.val.x[:,dim:]
y0z_sample0 = np.column_stack( (y0,z_sample0) )
y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)

## record validation loss
valid_loss_record = np.empty((0,5), float)

n_iter = 20000
for i in range(n_iter):
    optimizer.zero_grad()

    if i > 5000:
        optimizer.param_groups[0]["lr"] = 0.0001

    elif i > 3000:
        optimizer.param_groups[0]["lr"] = 0.0005


    if i % 500 == 0:
        print('iteration step: ' + '{0:1d}'.format(i))
        print('learning rate: ' + '{0:6f}'.format(optimizer.param_groups[0]["lr"]))


        for ii, y_sample_ii in enumerate(train_loader):
            y_sample_ii = y_sample_ii.to(device)

            loss, _, _, _ = loss_fun(NF, y_sample_ii, dim)
            print(i, ii, 'loss: ', loss)

        # validation loss
        valid_loss, loss1, loss2, loss3 = eval_logmean(NF, valid_loader, dim)
        print('valid loss: : %.6f' % valid_loss)
        print('------------------------------------------------')

        valid_loss_record = np.append(valid_loss_record, [[i, valid_loss.cpu().detach().numpy(), loss1.cpu().detach().numpy(), loss2.cpu().detach().numpy(), loss3.cpu().detach().numpy()]], axis=0)
        
        ## plotting
        # y0_y = NF.backward(y0z_sample)
        # y = y0_y[:,dim:2 * dim]
        # y_pred = y.to('cpu').detach().numpy()
        # plt.cla()      
        # ax = plt.scatter(y_test[:,1], y_test[:,0], c='r', marker='.')
        # ax = plt.scatter(y_pred[:,1], y_pred[:,0], c='b', marker='.')
        # plt.xlabel('cosine of pitch angle')
        # # plt.xlim(-1,1)
        # plt.ylabel('p')    

        # plt.legend(['exact samples', 'PRNF samples'],fontsize = 15,loc = 'upper left')
        # plt.savefig(savedir + '/img_' + str(i) + '.png', dpi='figure')
        # plt.pause(0.01)


    else:

        for ii, y_sample_ii in enumerate(train_loader):
            y_sample_ii = y_sample_ii.to(device)
            loss, _, _, _ = loss_fun(NF, y_sample_ii, dim)
    
    
    loss.backward()
    optimizer.step()


## Saving validation results vs epoch to .npy file  
with open(savedir + 'lambda1_valid_loss.npy', 'wb') as f:
    np.save(f, valid_loss_record )


# plt.savefig(savedir+'/result.png')

# save_model(NF)

exit()






















