
import numpy as np
import matplotlib.pyplot as plt
import datasets
from scipy.stats import gaussian_kde
from scipy.stats import norm
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'eval_result/'


p_star = 1.5

## data normaized back and periodic boundary condition:
with open(datasets.root + 're2d/data_mean_std.npy', 'rb') as f:
    mu = np.load(f)
    s = np.load(f)
dim = 2
fig, axes = plt.subplots(figsize=(4, 4), ncols=1, nrows=1)

PR_pred = np.zeros(10)
PR_test = np.zeros(10)

for idx in range(1,11):
    print(idx)

    # filename = savedir + 'valid_uniform'
    filename = savedir + 'maxwell_delta%d' %idx
    print(filename)
    with open(filename + '.npy', 'rb') as f:
        y_test = np.load(f)     # (p,xi)
        y_pred = np.load(f)

    y_test = y_test * s[dim:] + mu[dim:]
    y_pred = y_pred * s[dim:] + mu[dim:]
    # period boundary condition for y_pred
    y_pred[y_pred[:,1] >= 1,1] = y_pred[y_pred[:,1] >= 1,1] - 2*(y_pred[y_pred[:,1] >= 1,1] - 1)
    y_pred[y_pred[:,1] <= -1,1] = y_pred[y_pred[:,1] <= -1,1] + 2*( -1 - y_pred[y_pred[:,1] <= -1,1])

    p_min = 0.5
    y_pred[y_pred[:,0] <= p_min,0] = p_min


    #-----------------pred--------------
    data_type = 'pred'
    ## plotting prediction
    p = y_pred[:,0]
    p_max = np.max(p)
    p_min = np.min(p)

    if p_star > p_max:
        PR = 0
    else:
        pkde = gaussian_kde(p)
        ind_total = np.linspace(p_min,p_max,101)
        kdepdf_p_total = pkde.evaluate(ind_total)
        PR_total = (p_max - p_min)/100 * (np.sum(kdepdf_p_total[0:-1]) + np.sum(kdepdf_p_total[1:])) / 2.0

        ind_partial = np.linspace(p_star,p_max,101)
        kdepdf_p_partial = pkde.evaluate(ind_partial)
        PR_partial = (p_max - p_star)/100 * (np.sum(kdepdf_p_partial[0:-1]) + np.sum(kdepdf_p_partial[1:])) / 2.0
        PR = PR_partial / PR_total

    PR_pred[idx-1]=PR
    



    #-----------------test--------------
    data_type = 'test'
    ## plotting exact
    p = y_test[:,0]
    p_max = np.max(p)
    p_min = np.min(p)

    if p_star > p_max:
        PR = 0
    else:
        pkde = gaussian_kde(p)
        ind_total = np.linspace(p_min,p_max,101)
        kdepdf_p_total = pkde.evaluate(ind_total)
        PR_total = (p_max - p_min)/100 * (np.sum(kdepdf_p_total[0:-1]) + np.sum(kdepdf_p_total[1:])) / 2.0

        ind_partial = np.linspace(p_star,p_max,101)
        kdepdf_p_partial = pkde.evaluate(ind_partial)
        PR_partial = (p_max - p_star)/100 * (np.sum(kdepdf_p_partial[0:-1]) + np.sum(kdepdf_p_partial[1:])) / 2.0
        PR = PR_partial / PR_total

    PR_test[idx-1]=PR
    



axes.plot(np.arange(1,11),PR_pred, label='PRNF', color="r")
axes.plot(np.arange(1,11),PR_test, label='MC', color="b")
axes.set_xlabel('$\hat{T}_0$',fontsize=12)
axes.set_ylabel('$n_{RE}$',fontsize=12)  
axes.set_xlim(1,10)
axes.legend()
plt.tight_layout()
plt.grid()
plt.show()
plt.savefig('production.png', dpi='figure')
 
