
import numpy as np
import matplotlib.pyplot as plt
import datasets
from scipy.stats import gaussian_kde
from scipy.stats import norm
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'eval_result/'

# filename = savedir + 'valid_uniform'
filename = savedir + 'maxwell_delta10'
with open(filename + '.npy', 'rb') as f:
    y_test = np.load(f)     # (p,xi)
    y_pred = np.load(f)


## data normaized back and periodic boundary condition:
with open(datasets.root + 're2d/data_mean_std.npy', 'rb') as f:
    mu = np.load(f)
    s = np.load(f)
    
dim = 2
y_test = y_test * s[dim:] + mu[dim:]
y_pred = y_pred * s[dim:] + mu[dim:]

# period boundary condition for y_pred
y_pred[y_pred[:,1] >= 1,1] = y_pred[y_pred[:,1] >= 1,1] - 2*(y_pred[y_pred[:,1] >= 1,1] - 1)
y_pred[y_pred[:,1] <= -1,1] = y_pred[y_pred[:,1] <= -1,1] + 2*( -1 - y_pred[y_pred[:,1] <= -1,1])

p_min = 0.5
y_pred[y_pred[:,0] <= p_min,0] = p_min

p_max_b = np.minimum(max(y_test[:,0]),max(y_pred[:,0]))


# remove outliers delta = 1, pmax = 0.6; delta = 5, pmax = 2
p_max_out = 10
p_max_lim = 10
y_pred = np.delete(y_pred, np.where(y_pred[:,0] > p_max_out), 0)
y_test = np.delete(y_test, np.where(y_test[:,0] > p_max_out), 0)

print(y_pred.shape)
print(y_test.shape)
# exit()





fig, axes = plt.subplots(figsize=(8, 8), ncols=2, nrows=2)
l, b, h, w = 0.7, .65, .2, .24
ax2 = fig.add_axes([l, b, w, h])
#-----------------pred--------------
data_type = 'pred'
## plotting prediction
xi = y_pred[:,1]
p = y_pred[:,0]


xikde = gaussian_kde(xi)
ind = np.linspace(-1,1,51)
kdepdf_xi = xikde.evaluate(ind)
axes[0,0].plot(ind, kdepdf_xi, label='PRNF', color="r")


pkde = gaussian_kde(p)
ind = np.linspace(p_min,p_max_b,51)
kdepdf_p = pkde.evaluate(ind)
# axes[0,1].plot(ind, np.log10(kdepdf_p), label='kde', color="r")
axes[0,1].plot(ind, kdepdf_p, label='PRNF', color="r")
ax2.plot(ind, np.log10(kdepdf_p), color="r")


# Define the borders
deltaX = (max(xi) - min(xi))/100
deltaY = (max(p) - min(p))/100
xmin = min(xi) - deltaX
xmax = max(xi) + deltaX
ymin = min(p) - deltaY
ymax = max(p) + deltaY

## subplot(1,0): xi, p
# Create meshgrid
xx, yy = np.mgrid[xmin:xmax:50j, ymin:ymax:50j]
positions = np.vstack([xx.ravel(), yy.ravel()])
values = np.vstack([xi, p])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
# Plotting the kernel with annotated contours
levels = np.linspace(-4, 0, 9)
cfset = axes[1,0].contourf(xx, yy, np.log10(f+1e-10), levels=levels, cmap='coolwarm')
cset = axes[1,0].contour(xx, yy, np.log10(f+1e-10), levels=levels, colors='k')
axes[1,0].clabel(cset, inline=1, fontsize=10)
axes[1,0].set_xlabel('pitch angle $\\theta$',fontsize=10)
axes[1,0].set_ylabel('momentum p',fontsize=10)
axes[1,0].set_xlim(-1,1)
axes[1,0].set_ylim(0.5,10)
axes[1,0].invert_xaxis()
axes[1,0].set_xticks([-1,-0.5,0,0.5,1])
axes[1,0].set_xticklabels(['$\pi$','$3\pi/4$','$\pi/2$','$\pi/4$','$0$'])

#-----------------test--------------
data_type = 'test'
## plotting prediction
xi = y_test[:,1]
p = y_test[:,0]

xikde = gaussian_kde(xi)
ind = np.linspace(-1,1,51)
kdepdf_xi = xikde.evaluate(ind)
axes[0,0].plot(ind, kdepdf_xi, label='MC', color="b")
axes[0,0].set_xlabel('pitch angle $\\theta$',fontsize=10)
axes[0,0].set_ylabel('density',fontsize=10)
axes[0,0].set_xlim(-1,1)
axes[0,0].set_ylim(0,1)
axes[0,0].invert_xaxis()
axes[0,0].set_xticks([-1,-0.5,0,0.5,1])
axes[0,0].set_xticklabels(['$\pi$','$3\pi/4$','$\pi/2$','$\pi/4$','$0$'])

pkde = gaussian_kde(p)
ind = np.linspace(p_min,p_max_b,51)
kdepdf_p = pkde.evaluate(ind)
# axes[0,1].plot(ind, np.log10(kdepdf_p), label='kde', color="b")
axes[0,1].plot(ind, kdepdf_p, label='MC', color="b")
axes[0,1].set_xlabel('momentum p',fontsize=10)
axes[0,1].set_ylabel('density',fontsize=10)
axes[0,1].set_xlim(0,10)
axes[0,1].set_ylim(0,1)
ax2.plot(ind, np.log10(kdepdf_p), color="b")
ax2.set_xlim(0,10)
ax2.title.set_text('log-pdf')




# Define the borders
deltaX = (max(xi) - min(xi))/100
deltaY = (max(p) - min(p))/100
xmin = min(xi) - deltaX
xmax = max(xi) + deltaX
ymin = min(p) - deltaY
ymax = max(p) + deltaY

## subplot(1,0): xi, p
# Create meshgrid
xx, yy = np.mgrid[xmin:xmax:50j, ymin:ymax:50j]
positions = np.vstack([xx.ravel(), yy.ravel()])
values = np.vstack([xi, p])
kernel = gaussian_kde(values)
f = np.reshape(kernel(positions).T, xx.shape)
# Plotting the kernel with annotated contours
levels = np.linspace(-4, 0, 9)
cfset = axes[1,1].contourf(xx, yy, np.log10(f+1e-10), levels=levels, cmap='coolwarm')
cset = axes[1,1].contour(xx, yy, np.log10(f+1e-10), levels=levels, colors='k')
axes[1,1].clabel(cset, inline=1, fontsize=10)
axes[1,1].set_xlabel('pitch angle $\\theta$',fontsize=10)
axes[1,1].set_ylabel('momentum p',fontsize=10)
axes[1,1].set_xlim(-1,1)
axes[1,1].set_ylim(0.5,10)
axes[1,1].invert_xaxis()
axes[1,1].set_xticks([-1,-0.5,0,0.5,1])
axes[1,1].set_xticklabels(['$\pi$','$3\pi/4$','$\pi/2$','$\pi/4$','$0$'])
# axes[1,0].set_ylim(0,p_max_lim)

axes[0,0].legend()
axes[0,1].legend()
axes[0,0].title.set_text('1d marginal pdf in $\\theta$')
axes[0,1].title.set_text('1d marginal pdf in p')
axes[1,0].title.set_text('2d log-pdf by PRNF')
axes[1,1].title.set_text('2d log-pdf by MC')
plt.tight_layout()
plt.show()
plt.savefig(filename + '_contour.png', dpi='figure')
 
