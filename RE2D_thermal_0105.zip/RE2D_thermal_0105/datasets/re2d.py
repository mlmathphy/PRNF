import numpy as np
import matplotlib.pyplot as plt
import datasets


class RE2D:

    class Data:

        def __init__(self, data):

            self.x = data.astype(np.float)
            self.N = self.x.shape[0]

    def __init__(self):

        trn, val = load_data_normalised()

        self.trn = self.Data(trn)
        self.val = self.Data(val)

        self.n_dims = self.trn.x.shape[1]



def load_data():
    return np.load(datasets.root + 're2d/data.npy')


def load_data_split():

    rng = np.random.RandomState(42)

    data = load_data()
    rng.shuffle(data)
    N = data.shape[0]

    N_validate = int(0.2*data.shape[0])
    data_validate = data[-N_validate:]
    data_train = data[0:-N_validate]

    return data_train, data_validate,


def load_data_normalised():

    data_train, data_validate = load_data_split()

    # normalization
    with open(datasets.root + 're2d/data_mean_std.npy', 'rb') as f:
        mu = np.load(f)
        s = np.load(f)

    data_train = (data_train - mu)/s
    data_validate = (data_validate - mu)/s
    
    return data_train, data_validate
