
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import os
from scipy.stats import gaussian_kde
# set paths
root_output = 'output/'   # where to save trained models
root_data = 'data/'       # where the datasets are
savedir = 'data/visualre3d/'



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)

make_folder(savedir)


## dataset name: 
#---------------
data_name  = 're3d/data'
filename = root_data + data_name+  '.npy'

with open(filename, 'rb') as f:
    data = np.load(f)


# print('data name: ' + data_name)
print(data.shape)
p_0 = data[:,0]
xi_0 = data[:,1]
r_0 = data[:,2]
p_T = data[:,3]
xi_T = data[:,4]
r_T = data[:,5]



# figures (2D cross section)
fig = plt.figure(1, figsize=(10, 5))
ax = fig.add_subplot(1, 2, 1)
plt.ion()
plt.show()

ax1 = fig.add_subplot(1, 2, 2)
plt.ion()
plt.show()



ax.scatter(xi_T, p_T, marker='.',alpha=0.2, s=1.)
ax.set_xlabel('cos of pitch angle')
ax.set_xlim(-1,1)
ax.set_ylabel('p')   
ax.set_title('terminal positions')



ax1.scatter(r_T, p_T, marker='.',alpha=0.2, s=1.)
ax1.set_ylabel('p')  
ax1.set_xlabel('r')
ax1.set_xlim(0,1)
ax1.set_title('terminal positions')


plt.show()
plt.savefig(savedir + 'training_data' + '.png', dpi='figure')
 


 